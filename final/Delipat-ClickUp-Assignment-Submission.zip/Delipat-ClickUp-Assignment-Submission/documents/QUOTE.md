# QUOTE — Nordvik Consulting ClickUp Solution

**Currency conversion used for planning: 1 USD = INR 95.89; rate checked on 19 September 2026. Source: [https://hdfcsky.com/news/rupee-slips-0-3percent-to-95-89-as-fed-hike-and-104-brent-test-rbis-96-red-line](https://hdfcsky.com/news/rupee-slips-0-3percent-to-95-89-as-fed-hike-and-104-brent-test-rbis-96-red-line). FX is variable and this is a planning conversion, not a fixed billing rate.

## 1. Nordvik seat model

The assignment specifies:

- 12 Project Managers
- 27 Delivery Consultants
- **39 total people**

For the working quote, all 39 people are modelled as Workspace seats. The seat-mix analysis below explains why no guest/limited-seat savings are assumed without workspace evidence.

ClickUp states that users in one Workspace cannot be on different plans.

## 2. License pricing observed in the Nordvik workspace

The Nordvik Plans screen showed the newer Early access structure:

| Plan | Monthly billing | Yearly billing | 39 users, monthly billing | 39 users, yearly billing |
|---|---:|---:|---:|---:|
| Business | $24/user/mo | $16/user/mo | $936/mo | **$7,488/year** |
| Business Plus | $36/user/mo | $24/user/mo | $1,404/mo | **$11,232/year** |
| Enterprise | Custom | Custom | Custom | **Custom** |
| MAX | $120/user/mo | $100/user/mo | $4,680/mo | **$46,800/year** |

## 3. Yearly-billing savings versus monthly billing

| Plan | Monthly-billing annualised | Yearly-billing annual total | Difference |
|---|---:|---:|---:|
| Business | $11,232 | $7,488 | **$3,744** |
| Business Plus | $16,848 | $11,232 | **$5,616** |
| MAX | $56,160 | $46,800 | **$9,360** |

Enterprise is not calculable without a sales quote.

## 4. AI/add-on treatment

The Nordvik workspace did not show an Add-ons tab/button.

Its newer plan cards showed ClickUp Brain² and different AI credit/model levels included within Business, Business Plus, Enterprise and MAX.

Therefore:

- **No separate legacy Brain/Everything AI charge is added to this quote.**
- AI packaging is marked as workspace-specific and subject to change.
- Any future AI add-on or credit purchase should be quoted only after the actual Nordvik billing screen exposes it.

## 5. Working commercial baseline

**Working baseline:** Business, billed yearly, for 39 seats.

Business yearly is used as the working quote baseline because the demonstrated billing workflow was successfully tested during the Business trial.

Business Plus is shown as an alternative because it adds advanced Workload capacity controls, Custom Roles, advanced time tracking/forms and higher API/automation limits.

This is a commercial baseline, not a claim that Business is the only possible solution.

## 6. One-time delivery estimates

These are **implementation estimates**, not ClickUp list prices.

| Item | Planning estimate |
|---|---:|
| ClickUp workspace setup, hierarchy, fields, views, dashboard, permissions and training | $2,500 |
| e-conomic integration: invoice payload, authentication, mapping, invoice-number write-back and testing | $4,000 |
| Country-calendar utilisation workaround/custom capacity layer for Denmark/India/Sweden | $3,000 |
| **Total one-time delivery estimate** | **$9,500** |

These estimates should be validated with a real implementation scope before a customer contract.

## 7. Ongoing support estimate

Planning estimate:

- **$600/month**
- **$7,200/year**

This covers routine configuration support, monitoring of the integration, minor workflow changes and operational assistance. It is not a ClickUp fee.

## 8. First-year working quote — Business

| Component | USD | INR @ 95.89/USD |
|---|---:|---:|
| Business annual licenses — 39 users | $7,488 | INR 718,024 |
| ClickUp workspace setup | $2,500 | INR 239,725 |
| e-conomic custom integration | $4,000 | INR 383,560 |
| Country utilisation custom work | $3,000 | INR 287,670 |
| 12 months support | $7,200 | INR 690,408 |
| **First-year working total** | **$24,188** | **INR 2,319,387** |

Rounded customer-facing INR figure: **INR 23.19 lakh**.

## 9. Recurring cost from year two

If the same support arrangement continues:

- Business yearly license: **$7,488/year**
- Support: **$7,200/year**
- **Base recurring estimate: $14,688/year**
- At INR 95.89/USD: approximately **INR 14.09 lakh/year**

Custom integration maintenance or major new features are excluded from the recurring support figure.

## 10. Business Plus comparison

If Nordvik selects Business Plus instead:

- Annual licenses: **$11,232**
- Difference from Business: **+$3,744/year**
- At INR 95.89/USD: approximately **+INR 359,012/year** at the stated planning rate

The higher plan provides advanced Workload capacity controls, Custom Roles, advanced time tracking/forms and higher API/automation limits.

It still does not natively provide independent Denmark/India/Sweden Workspace work schedules.

## 11. Commercial assumptions and exclusions

- Prices are based on the Nordvik workspace's displayed Early access pricing.
- Taxes are excluded from the working quote because the customer's tax treatment and billing location were not supplied.
- Enterprise is excluded from numeric comparison because it is custom-priced.
- MAX is shown for comparison, not selected for the working quote.
- Implementation/custom-build/support figures are planning estimates, not ClickUp vendor prices.
- FX is variable.
- e-conomic subscription/API/commercial charges, if any, are not included.
- No payment method or paid subscription was purchased during testing.
- Core plan pricing was not captured in the Nordvik workspace and is therefore not included in the working quote.

## Sources

- [ClickUp pricing per user role and plan](https://help.clickup.com/hc/en-us/articles/6303244318999-Pricing-per-user-role-and-plan)
- [ClickUp new plans and pricing](https://help.clickup.com/hc/en-us/articles/42972527662359-New-plans-and-pricing-options)
- [ClickUp API](https://developer.clickup.com/docs/Getting%20Started)
- [e-conomic developer documentation](https://www.e-conomic.com/developer/documentation)
- [e-conomic REST API](https://restdocs.e-conomic.com/)

### Seat-mix decision for the 39 people

| Nordvik role | People | Working seat model | Quote treatment | Reason |
|---|---:|---|---|---|
| Project Managers | 12 | Workspace Members | Included in 39-seat paid baseline | PMs need full delivery-management, reporting and workspace access. |
| Delivery Consultants | 27 | Workspace Members | Included in 39-seat paid baseline | Consultants need to work on delivery tasks and time/capacity workflows; a guest/limited-seat model was not demonstrated as sufficient in the Nordvik workspace. |
| Guest / limited-seat alternative | 0 quoted | Not assumed | Not included in totals | The assignment requires role/permission fit, and the observed workspace did not provide enough evidence to claim a cheaper guest mix or price it safely. |

**Commercial decision:** The working quote uses **39 paid Workspace seats** rather than inventing savings from guest/limited users. This is conservative and evidence-based. If Nordvik later confirms that some consultants can operate as guests/limited members without losing required delivery and time-tracking permissions, the quote should be recalculated from the actual billing screen.


